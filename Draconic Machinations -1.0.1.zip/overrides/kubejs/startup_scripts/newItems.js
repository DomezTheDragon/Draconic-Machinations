StartupEvents.registry('item', event => {

  // You can chain builder methods as much as you like
  event.create('dull_pearl').displayName('Dull Pearl')
  event.create('creative_shard').displayName('Creative Shard')
  event.create('creative_star').displayName('Creative Star')
})