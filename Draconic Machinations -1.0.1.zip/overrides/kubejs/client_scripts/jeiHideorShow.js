JEIEvents.hideItems(event => {
  event.hide('example:ingredient')
})

JEIEvents.removeCategories(event => {
  event.remove('create:compacting')
  event.remove('jumbofurnace:jumbosmelting')
  event.remove('jumbofurnace:jumbofurnaceupgrade')
})