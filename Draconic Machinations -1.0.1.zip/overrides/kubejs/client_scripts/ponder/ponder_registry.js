Ponder.tags((event) => {
    event.createTag("draconic_machinations:mekanism", "mekanism:steel_casing", "Mekanism Multiblocks", "How to make and use Mekanism Multiblocks", [
        "mekanism:boiler_casing",
        "mekanismgenerators:turbine_casing",
        "mekanism:thermal_evaporation_block",
        "mekanismgenerators:fission_reactor_casing",
        "mekanismgenerators:fusion_reactor_frame",
        "mekanism_extras:naquadah_reactor_casing",
        "mekanism:sps_casing",
        "mekanism:induction_casing",
        "mekanism:dynamic_tank"
    ]);
});