Ponder.registry((event) => {
    event.create(
            "mekanismgenerators:turbine_casing").scene(
            "turbine_setup",
            "The Turbine Multiblock",
            "kubejs:turbine_setup",
            (scene, util) => {
                scene.scaleSceneView(0.65);
                scene.setSceneOffsetY(-2);

                scene.world.showSection([0,0,0, 7,0,7], Facing.UP);
                scene.idle(25);
                scene.world.showSection([3,1,3, 7,10,7], Facing.DOWN);
                scene.idle(20);

                scene.overlay.showOutline(PonderPalette.RED, "TurbineOutline1", util.select.fromTo(3,1,3, 7,10,7), 60);
                scene.idle(10);
                scene.text(50, "This is a Steam Turbine.", [3,5.5,8]).colored(PonderPalette.RED);
                scene.idle(60);
                scene.text(75, "Its size can range from 5x5x6 to 17x17x18.", [3,5.5,8]).colored(PonderPalette.BLUE);
                scene.idle(85);

                scene.overlay.showOutline(PonderPalette.BLUE, "TurbineVents1", util.select.fromTo(3,7,6, 3,9,4), 60);
                scene.overlay.showOutline(PonderPalette.BLUE, "TurbineVents2", util.select.fromTo(4,7,3, 6,9,3), 60);
                scene.overlay.showOutline(PonderPalette.BLUE, "TurbineVents3", util.select.fromTo(6,10,6, 4,10,4), 60);
                scene.text(50, "These are turbine vents, used to pull water out of the turbine.", [3,8.5,5.5]).colored(PonderPalette.BLUE).attachKeyFrame();
                scene.idle(60);

                scene.overlay.showOutline(PonderPalette.WHITE, "TurbineValve1", util.select.position(5,2,3), 60);
                scene.overlay.showOutline(PonderPalette.GREEN, "TurbineValve2", util.select.position(3,2,5), 60);
                scene.text(50, "These are turbine valves, used to put steam in and take energy out.", [3,2.5,5.5]).colored(PonderPalette.GREEN).attachKeyFrame();
                scene.idle(60);
                scene.rotateCameraY(30);
                scene.idle(25)
                scene.world.hideSection([4,2,3, 6,10,3], Facing.UP);
                scene.world.hideSection([4,7,4, 6,10,6], Facing.UP);
                scene.idle(30);
                scene.overlay.showOutline(PonderPalette.RED, "RotorOutline", util.select.fromTo(5,2,5, 5,6,5), 130);
                scene.text(120, "These are Turbine Rotors. You need 2 Turbine Blades per Rotor. Place between 4 and 10, depending on turbine size.", [5.5,4.5,5.5]).colored(PonderPalette.RED).attachKeyFrame();
                scene.idle(125);
                scene.world.showSection([6,7,6, 4,7,4], Facing.SOUTH);
                scene.idle(30);
                scene.overlay.showOutline(PonderPalette.RED, "DisperserOutline", util.select.fromTo(6,7,6, 4,7,4), 130);
                scene.text(120, "Place a Rotational Complex above the top Turbine Rotor, then fill in that layer with Pressure Dispersers.", [5.5,8,5.5]).colored(PonderPalette.RED).attachKeyFrame();
                scene.idle(125);
                scene.world.showSection([6,8,6, 4,8,4], Facing.SOUTH);
                scene.idle(30);
                scene.overlay.showOutline(PonderPalette.RED, "CoilOutline", util.select.fromTo(6,8,6, 4,8,4), 90);
                scene.text(80, "On the next layer, place one Electromagnetic Coil per 2 Rotors, like so.", [5.5,9,5.5]).colored(PonderPalette.RED).attachKeyFrame();
                scene.idle(85);
                scene.world.showSection([6,9,6, 4,9,4], Facing.SOUTH);
                scene.idle(30);
                scene.overlay.showOutline(PonderPalette.RED, "CoilOutline", util.select.fromTo(6,9,6, 4,9,4), 70);
                scene.text(60, "Next, place Saturating Condensers. You only need 1 per 32000 mb of Steam/tick that will pass through the turbine.", [5.5,10,5.5]).colored(PonderPalette.RED).attachKeyFrame();
                scene.idle(65);
                scene.world.showSection([4,10,6, 6,2,3], Facing.SOUTH);
                scene.idle(30);
                scene.overlay.showOutline(PonderPalette.RED, "TurbineOutline", util.select.fromTo(3,1,3, 7,10,7), 70);
                scene.text(60, "Finish the outside of the turbine, and you're done!", [3,5.5,8]).colored(PonderPalette.RED).attachKeyFrame();
                scene.rotateCameraY(-30);
                scene.idle(65);
            }
        )
        })