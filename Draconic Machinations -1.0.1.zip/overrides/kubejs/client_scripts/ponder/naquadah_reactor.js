Ponder.registry((event) => {
    event.create(
            "mekanism_extras:naquadah_reactor_casing").scene(
            "naquadah_reactor",
            "The Naquadah Reactor",
            "kubejs:naquadah_reactor",
            (scene, util) => {
                scene.scaleSceneView(0.5);
                scene.setSceneOffsetY(-2);
                
                scene.world.showSection([0,0,0, 11,0,11], Facing.UP);
                scene.idle(25);
                scene.world.showSection([0,1,0, 11,9,11], Facing.DOWN); //these may need to be edited to fit the size of the naquadah reactor
                scene.idle(20);
                
		scene.overlay.showOutline(PonderPalette.GREEN, "naqOutlineFull", util.select.fromTo(3,1,3, 11,9,11), 60);
                scene.idle(10);
                scene.text(50, "This is a Naquadah Reactor. It is very similar to a Fusion Reactor.",[5,5,10]).colored(PonderPalette.GREEN);
                scene.idle(60);
		
		scene.text(70, "It burns special fuels to produce Energy, Heat, or can use that Heat to enrich Water into Polonium-containing Steam.").attachKeyFrame();
                scene.idle(80);
		scene.text(70, "Enriching water or removing the heat via Thermodynamic Conductors causes the reactor's energy generation to slow.");
                scene.idle(80);
		scene.text(70, "However, Polonium-containing Steam can be refined into Polonium, so do what works for you.");
                scene.idle(80);

		scene.idle(20);
		scene.text(70, "The Naquadah Reactor can use either Rich Silicon Fuel and Rich Uranium Fuel, or only Silicon Uranium Fuel.").attachKeyFrame();
                scene.idle(80);
		scene.text(70, "Rich Silicon Fuel and Rich Uranium Fuel can be stored in the reactor, and burned off slowly.");
                scene.idle(80);
		scene.text(70, "Silicon Uranium Fuel requires 1000 mb of fuel added to the reactor every tick, or the reaction stops.");
                scene.idle(80);
		scene.text(70, "However, Silicon Uranium Fuel is a much better fuel than Rich Silicon Fuel and Rich Uranium Fuel, so if you want a super-powerful Reactor, use Silicon Uranium Fuel.");
                scene.idle(80);
		
		scene.idle(20);
		scene.text(50, "This is a Naquadah Reactor Controller.").attachKeyFrame();
		scene.overlay.showOutline(PonderPalette.GREEN, "naqController", util.select.position(7,9,7),200);
                scene.idle(60);
		scene.text(50, "Unlike the Fusion Reactor, you can open the menu from any glass on the reactor.");
                scene.idle(60);
		scene.text(70, "Before the reaction can start, a Hohlraum filled with 100 Silicon Uranium Fuel must be inside the one slot.");
                scene.idle(80);
		scene.showControls(50, [7,10,7], "down").withItem("mekanism_extras:naquadah_hohlraum");

		scene.idle(80);
		scene.text(50, "This is a Laser Focus Matrix.").attachKeyFrame();
		scene.overlay.showOutline(PonderPalette.GREEN, "naqFocus", util.select.position(7,5,3),200);
                scene.idle(60);
		scene.text(50, "You can start the reaction by blasting a laser with 1 GFE into it.");
                scene.idle(60);
		scene.text(70, "This is nigh-impossible with regular lasers, so you will need to use a Laser Amplifier's build-up setting to do this.");
                scene.idle(80);
		
		scene.idle(20);
		scene.text(50, "Inputs and Outputs will work with whatever type of cable/pipe is connected.").attachKeyFrame();
		scene.overlay.showOutline(PonderPalette.GREEN, "fusionIO", util.select.fromTo(3,5,6, 3,5,8),110);
                scene.idle(60);
		scene.text(50, "To swap between Input and Output, sneak-right-click with a Configurator.");
                scene.idle(60);
		scene.showControls(50, [3,5,8], "down").rightClick().whileSneaking().withItem("mekanism:configurator");
                scene.world.modifyBlock([3,5,7], (curState) => curState.with("active", "true"), false);
		scene.idle(60);
		
                //make sure to look at the other ponders to get a general idea on what to do and what to point out

                //make sure to state that this is rather similar to the fusion reactor

                //explain that it can either use rich silicon fuel and rich uranium fuel as fuel, or Silicon Uranium fuel, but you need a supply of over 1000mb/t of Silicon Uranium fuel for injecting it directly

                //also explain that you need a laser that has at least 1GFE built up in order to start it, and you need a Naquadah Hohlraum filled with Silicon Uranium fuel inside of the reactor

                //then explain that you can put in water to turn it into polonium containing steam, that can be processed into polonium
            }
        )
        })