Ponder.registry((event) => {
    event.create(
            "mekanism:induction_casing").scene(
            "induction_matrix",
            "The Induction Matrix",
            "kubejs:induction_matrix",
            (scene, util) => {
                scene.scaleSceneView(0.65);
                scene.setSceneOffsetY(-2);
                //scene.showStructure();
                
                scene.world.showSection([0,0,0, 7,0,7], Facing.UP);
                scene.idle(25);
                scene.world.showSection([3,1,3, 7,5,7], Facing.DOWN);
                scene.idle(20);

                scene.overlay.showOutline(PonderPalette.GREEN, "matrixOutline1", util.select.fromTo(3,1,3, 7,5,7), 60);
                scene.idle(10);
                scene.text(50, "This is an Induction Matrix. It is used to store massive amounts of energy.",[3,3,8]).colored(PonderPalette.GREEN);
                scene.idle(60);
                scene.text(50, "It can be any size from 3x3x3 to 18x18x18.",[3,3,8]);
                scene.idle(60);

                scene.overlay.showOutline(PonderPalette.GREEN, "inductionPort1", util.select.position(5,2,3),60);
                scene.overlay.showOutline(PonderPalette.GREEN, "inductionPort2", util.select.position(3,2,5),60);
                scene.idle(10);
                scene.text(50, "It requires Induction Ports to input and output energy.", [5.5,2.5,3.5]).colored(PonderPalette.GREEN).attachKeyFrame();
                scene.idle(60);
                
                scene.world.modifyBlock([3,2,5], (curState) => curState.with("active", "true"), false);
                scene.text(50, "To activate the output on a port, you use a configurator", [3,2.5,5.5]).colored(PonderPalette.GREEN); 
                scene.showControls(50, [3,3,5], "down").rightClick().whileSneaking().withItem("mekanism:configurator");
                scene.idle(60);
                
                scene.world.hideSection([6,5,3, 3,2,3], Facing.UP);
                scene.world.hideSection([3,5,6, 3,2,4], Facing.UP);
                scene.world.hideSection([4,5,4, 6,5,6], Facing.UP);

                scene.overlay.showOutline(PonderPalette.GREEN,"inductionStorage1", util.select.fromTo(4,2,4, 6,4,6), 60);
                scene.idle(10);
                scene.text(50, "You can put induction components inside however you like. It does not matter.").colored(PonderPalette.GREEN).attachKeyFrame();
                scene.idle(60);
                

                scene.overlay.showOutline(PonderPalette.GREEN,"inductionCell1", util.select.fromTo(5,2,4, 6,2,4), 60);
                scene.overlay.showOutline(PonderPalette.GREEN,"inductionCell2", util.select.fromTo(4,4,6, 5,4,6), 60);
                scene.idle(10);
                scene.text(50, "These are Induction Cells. The more there are, the more energy the structure can store.", [5,3,5]).colored(PonderPalette.GREEN).attachKeyFrame();
                scene.idle(60);

                scene.overlay.showOutline(PonderPalette.GREEN,"inductionProvider1", util.select.fromTo(4,2,6, 4,2,5), 60);
                scene.overlay.showOutline(PonderPalette.GREEN,"inductionProvider2", util.select.fromTo(6,2,6, 6,3,6), 60);
                scene.idle(10);
                scene.text(50, "These are Induction Providers. The more there are, the more energy the structure can input/output.", [5,3,5]).colored(PonderPalette.GREEN);
                scene.idle(60);

		scene.idle(10);
		scene.text(70, "Finally, Absolute, Supreme, Cosmic, and Infinite tier components require a stronger Induction Matrix.").colored(PonderPalette.GREEN).attachKeyFrame();
                scene.idle(80);
		scene.text(70, "You need to replace all of the normal Induction Casings and Induction Ports with Reinforced variants.").colored(PonderPalette.GREEN);
                scene.idle(80);
		scene.text(70, "However, Reinforced Induction Matrices are too strong for normal Induction Components, and cannot support them.").colored(PonderPalette.GREEN);
                scene.idle(80);
              

            }
        )
        })