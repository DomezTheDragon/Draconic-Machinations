Ponder.registry((event) => {
    event.create(
            "mekanism:boiler_casing").scene(
            "boiler_setup",
            "The Boiler Multiblock",
            "kubejs:boiler_setup",
            (scene, util) => {
                scene.scaleSceneView(0.65);
                scene.setSceneOffsetY(-2);

                scene.world.showSection([0,0,0, 7,0,7], Facing.UP);
                scene.idle(25);
                scene.world.showSection([3,1,3, 7,10,7], Facing.DOWN);
                scene.idle(20);

                scene.overlay.showOutline(PonderPalette.RED, "BoilerOutline1", util.select.fromTo(3,1,3, 7,10,7), 60);
                scene.idle(10);
                scene.text(50, "This is a Thermoelectric Boiler...", [3,5.5,8]).colored(PonderPalette.RED);
                scene.idle(60);
                scene.text(75, "...It's Size can range from 3x3x4 to 18x18x18", [3,5.5,8]).colored(PonderPalette.BLUE);
                scene.idle(85);

                scene.overlay.showOutline(PonderPalette.RED, "HeatInput", util.select.position(4,2,3), 130);
                scene.text(55, "You can either insert heat directly, or...", [4.5,2.5,3]).colored(PonderPalette.RED).attachKeyFrame();
                scene.idle(65);
                scene.text(55, "...You can put in superheated sodium", [4.5,2.5,3]).colored(PonderPalette.RED);
                scene.showControls(55, [4.5,3,3], "down").withItem("mekanism:superheated_sodium_bucket");
                
                scene.idle(65);
                scene.overlay.showOutline(PonderPalette.BLUE, "WaterInput", util.select.position(6,2,3), 65);
                scene.text(55, "You also need to put in water", [6.5,2.5,3]).colored(PonderPalette.BLUE);
                scene.showControls(55, [6.5,3,3], "down").withItem("minecraft:water_bucket");

                scene.idle(65);
                scene.overlay.showOutline(PonderPalette.RED, "SteamOutput1", util.select.position(3,2,4), 65);
                scene.text(55, "The boiler will produce steam...", [3,2.5,4.5]).colored(PonderPalette.RED).attachKeyFrame();
                scene.idle(65);
                scene.text(55, "...In order to get it out, use a configurator on the valve", [3,2.5,4.5]).colored(PonderPalette.RED);
                scene.idle(65);
                scene.showControls(40, [3,3,4.5], "down").rightClick().whileSneaking().withItem("mekanism:configurator");
                scene.world.modifyBlock([3,2,4], (curState) => curState.with("mode", "output_steam"), false);

                scene.idle(65);
                scene.overlay.showOutline(PonderPalette.RED, "SteamOutput2", util.select.position(3,2,6), 65);
                scene.text(55, "The boiler will also cool the coolant, so use a configurator twice to output it", [3,2.5,6.5]).colored(PonderPalette.RED);
                scene.idle(65);
                scene.showControls(40, [3,3,6.5], "down").rightClick().whileSneaking().withItem("mekanism:configurator");
                scene.world.modifyBlock([3,2,6], (curState) => curState.with("mode", "output_steam"), false);
                scene.idle(10);
                scene.world.modifyBlock([3,2,6], (curState) => curState.with("mode", "output_coolant"), false);

                scene.idle(65);
                scene.world.hideSection([3,10,6, 3,2,3], Facing.UP);
                scene.world.hideSection([6,10,3, 4,2,3], Facing.UP);
                scene.world.hideSection([4,10,4, 6,10,6], Facing.UP);
                scene.idle(50);
                scene.overlay.showOutline(PonderPalette.RED, "Superheating", util.select.fromTo(4,2,4, 6,2,6), 60);
                scene.text(55, "These are superheating elements...", [6.25,2,6.75]).colored(PonderPalette.RED).attachKeyFrame();
                scene.idle(65);
                scene.text(55, "...the more you have, the faster the boil rate",[6.25,2,6.75]).colored(PonderPalette.RED);
                scene.idle(65);

                scene.overlay.showOutline(PonderPalette.WHITE, "Pressuredisperser1", util.select.fromTo(6,7,6, 4,7,4), 75);
                scene.text(85, "These are Pressure Dispersers, they seperate the water and steam tanks", [6.25,7,6.75]).colored(PonderPalette.WHITE).attachKeyFrame();
                scene.idle(95);
                scene.world.showSection([3,10,6, 3,2,3], Facing.DOWN);
                scene.world.showSection([6,10,3, 4,2,3], Facing.DOWN);
                scene.world.showSection([4,10,4, 6,10,6], Facing.DOWN);

                
            }
        )
        })