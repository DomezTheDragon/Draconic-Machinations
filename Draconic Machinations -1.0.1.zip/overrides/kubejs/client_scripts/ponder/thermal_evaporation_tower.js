Ponder.registry((event) => {
    event.create(
            "mekanism:thermal_evaporation_block").scene(
            "thermal_evaporation_tower",
            "The Thermal Evaportation Tower",
            "kubejs:thermal_evaporation_tower",
            (scene, util) => {
                scene.scaleSceneView(0.65);
                scene.setSceneOffsetY(-2);
                
                scene.world.showSection([0,0,0, 7,0,7], Facing.UP);
                scene.idle(25);
                scene.world.showSection([3,1,3, 6,4,6], Facing.DOWN);
                scene.idle(20);
                
                scene.overlay.showOutline(PonderPalette.RED, "thermalOutline1", util.select.fromTo(3,1,3, 6,4,6), 60);
                scene.idle(10);
                scene.text(50, "This is a Thermal Evaporation Tower.", [3,2.5,7]).colored(PonderPalette.RED);
                scene.idle(60);
                scene.text(75, "It must be 4x4, but it can be as short as 4 blocks or as tall as 18.", [3,2.5,7]).colored(PonderPalette.RED);
                scene.idle(85);
                
                scene.overlay.showOutline(PonderPalette.RED, "thermalController1", util.select.position(4,2,3), 60);
                scene.text(55, "A Thermal Evaporation Tower needs a controller to work.", [4.5,2,3.5]).colored(PonderPalette.RED).attachKeyFrame();
                scene.idle(60);
                scene.text(55, "You can use it to check the processes and temperature within.", [4.5,2,3.5]).colored(PonderPalette.RED);
                scene.idle(80);

                scene.overlay.showOutline(PonderPalette.BLUE, "thermalValve1", util.select.position(5,2,3), 60);
                scene.overlay.showOutline(PonderPalette.BLUE, "thermalValve2", util.select.position(3,2,5), 60);
                scene.text(55, "You can input and output liquids using the Thermal Evaporation Valves.", [3,2.5,5.5]).colored(PonderPalette.BLUE).attachKeyFrame();
                scene.idle(65);
                
                scene.overlay.showOutline(PonderPalette.RED, "heatRequirement1", util.select.position(5,2,3), 60);
                scene.overlay.showOutline(PonderPalette.RED, "heatRequirement2", util.select.position(3,2,5), 60);
                scene.text(55, "It requires heat to work. You can use a Fuelwood Heater, Resistive Heater, or...", [3,2.5,5.5]).colored(PonderPalette.RED).attachKeyFrame();
                scene.idle(65);
                scene.world.setBlock([3,4,3], "mekanismgenerators:advanced_solar_generator", false);
                scene.world.setBlock([6,4,3], "mekanismgenerators:advanced_solar_generator", false);
                scene.world.setBlock([3,4,6], "mekanismgenerators:advanced_solar_generator", false);
                scene.world.setBlock([6,4,6], "mekanismgenerators:advanced_solar_generator", false);
                scene.idle(15);
                scene.text(55, "...Advanced Solar Generators.", [3.5,4.5,3.5]).colored(PonderPalette.RED);
                scene.idle(65);
            }
        )
        })
        

        /*aaaa
        this is a comment that spams throughout multiple lines
        very nifty for disabling a section of code!*/                                                     