Ponder.registry((event) => {
    event.create(
            "mekanism:sps_casing").scene(
            "supercritical_phase_shifter",
            "The Supercritical Phase Shifter",
            "kubejs:supercritical_phase_shifter",
            (scene, util) => {
                scene.scaleSceneView(0.65);
                scene.setSceneOffsetY(-2);
                scene.showStructure();
                
		scene.overlay.showOutline(PonderPalette.GREEN, "spsOutlineFull", util.select.fromTo(2,1,2, 8,7,8), 60);
                scene.idle(10);
                scene.text(50, "This is a Supercritical Phase Shifter (SPS). It is used to convert polonium to antimatter.",[2,7,5]).colored(PonderPalette.GREEN);
                scene.idle(60);

		scene.world.hideSection([2,2,2, 7,7,6], Facing.UP);
                scene.text(50, "Ports may be placed anywhere on the sides. (Anywhere there is glass shown here.)",[5,7,5]);
                scene.idle(70);
		scene.text(30, "There are three kinds of ports.").attachKeyFrame();
                scene.idle(40);

		scene.text(50, "Energy inputs, which require a Supercharged Coil on the inside.", [5,4.5,8.5]);
                scene.overlay.showOutline(PonderPalette.GREEN, "spsOutlineEnergy", util.select.fromTo(5,4,8, 5,4,7), 60);
		scene.idle(60);

		scene.text(50, "Polonium input, which requires nothing special.", [8,5,5]);
                scene.overlay.showOutline(PonderPalette.GREEN, "spsOutlinePolonium", util.select.fromTo(8,4,4, 8,4,4), 60);
		scene.idle(60);

		scene.text(50, "And the Antimatter output, which needs to be configured.");
                scene.idle(80);

		scene.world.modifyBlock([8,5,6], (curState) => curState.with("active", "true"), false);
		scene.showControls(50, [8.5,5.5,6.5], "down").rightClick().whileSneaking().withItem("mekanism:configurator");
                scene.idle(60);
		
		scene.world.showSection([2,2,2, 7,7,6], Facing.UP);
		
		scene.text(90, "You may have as many of each as you want, but you only need 4: 2 energy inputs, and one Polonium input and Antimatter output.").attachKeyFrame();
                scene.idle(100);
		
		scene.text(90, "The SPS requires 1000 mb of polonium and 400 MFE to create one millibucket of antimatter.").attachKeyFrame();
                scene.idle(100);
		scene.text(90, "Be careful, as it will eat all the energy you give it, even if it will be wasted!");
                scene.idle(100);
		
               
            }
        )
        })