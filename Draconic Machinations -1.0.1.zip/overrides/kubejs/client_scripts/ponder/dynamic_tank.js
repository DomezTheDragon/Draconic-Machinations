Ponder.registry((event) => {
    event.create(
            "mekanism:dynamic_tank").scene(
            "dyamic_tank",
            "The Dynamic Tank",
            "kubejs:dynamic_tank",
            (scene, util) => {
                scene.scaleSceneView(0.65);
                scene.setSceneOffsetY(-2);
                
                scene.world.showSection([0,0,0, 7,0,7], Facing.UP);
                scene.idle(25);
                scene.world.showSection([3,1,3, 7,5,7], Facing.DOWN);
                scene.idle(20);

                scene.overlay.showOutline(PonderPalette.WHITE, "tankOutline1", util.select.fromTo(3,1,3, 7,5,7), 60);
                scene.idle(10);
                scene.text(50, "This is a Dynamic Tank, it can store liquids and gasses",[3,3,8]);
                scene.idle(60);

                scene.overlay.showOutline(PonderPalette.BLUE, "tankValve1", util.select.position(3,2,5), 60);
                scene.overlay.showOutline(PonderPalette.BLUE, "tankValve2", util.select.position(5,2,3), 60);
                scene.idle(10);
                scene.text(50, "It uses valves to put fluids in and to take them out", [3,2.5,5.5]).colored(PonderPalette.BLUE);
                scene.idle(60);
                scene.text(70, "Whether a valve inputs or outputs fluids depends on the pipes connected to it", [3,2.5,5.5]).colored(PonderPalette.BLUE);
                scene.idle(80);
            }
        )
        })