Ponder.registry((event) => {
    event.create(
            "mekanismgenerators:fusion_reactor_frame").scene(
            "fusion_reactor",
            "The Fusion Reactor",
            "kubejs:fusion_reactor",
            (scene, util) => {
                scene.scaleSceneView(0.65);
                scene.setSceneOffsetY(-2);
                
                scene.world.showSection([0,0,0, 7,0,7], Facing.UP);
                scene.idle(15);
                scene.world.showSection([3,1,3, 7,5,7], Facing.DOWN);
                scene.idle(20);
                

		scene.overlay.showOutline(PonderPalette.GREEN, "fusionOutlineFull", util.select.fromTo(3,1,3, 7,5,7), 60);
                scene.idle(10);
                scene.text(50, "This is a Fusion Reactor. It can generate massive amounts of energy.",[3,3,8]).colored(PonderPalette.GREEN);
                scene.idle(60);
		
		scene.text(70, "It burns Deuterium and Tritium to produce Energy, Heat, or can use that Heat to boil Water into Steam.").attachKeyFrame();
                scene.idle(80);
		scene.text(70, "Boiling water or removing the heat via Thermodynamic Conductors causes the reactor's energy generation to slow.");
                scene.idle(80);
		scene.text(70, "However, Steam and Heat can be used with other machines for more effective power generation, so do what works for you.");
                scene.idle(80);

		scene.idle(20);
		scene.text(70, "The Fusion Reactor can use either Deuterium and Tritium, or only D-T Fuel.").attachKeyFrame();
                scene.idle(80);
		scene.text(70, "Deuterium and Tritium can be stored in the reactor, and burned off slowly.");
                scene.idle(80);
		scene.text(70, "D-T Fuel requires 1000 mb of fuel added to the reactor every tick, or the reaction stops.");
                scene.idle(80);
		scene.text(70, "However, D-T Fuel is a much better fuel than Deuterium and Tritium, so if you want a super-powerful Reactor, use D-T Fuel.");
                scene.idle(80);
		
		scene.idle(20);
		scene.text(50, "This is a Fusion Reactor Controller.").attachKeyFrame();
		scene.overlay.showOutline(PonderPalette.GREEN, "fusionController", util.select.position(5,5,5),200);
                scene.idle(60);
		scene.text(50, "This is the only place you can open the Fusion Reactor's menu.");
                scene.idle(60);
		scene.text(70, "Before the reaction can start, a Hohlraum filled with 10 D-T Fuel must be inside the one slot.");
                scene.idle(80);
		scene.showControls(50, [5.5,5.5,5.5], "down").withItem("mekanismgenerators:hohlraum");

		scene.idle(70);
		scene.text(50, "This is a Laser Focus Matrix.").attachKeyFrame();
		scene.overlay.showOutline(PonderPalette.GREEN, "fusionFocus", util.select.position(5,3,3),200);
                scene.idle(60);
		scene.text(50, "You can start the reaction by blasting a laser with 1 GFE into it.");
                scene.idle(60);
		scene.text(70, "This is nigh-impossible with regular lasers, so you will need to use a Laser Amplifier's build-up setting to do this.");
                scene.idle(80);
		
		scene.idle(20);
		scene.text(50, "Inputs and Outputs will work with whatever type of cable/pipe is connected.").attachKeyFrame();
		scene.overlay.showOutline(PonderPalette.GREEN, "fusionIO", util.select.fromTo(3,3,4, 3,3,6),110);
                scene.idle(60);
		scene.text(50, "To swap between Input and Output, sneak-right-click with a Configurator.");
                scene.idle(60);
		scene.showControls(50, [3.5,3.5,6.5], "down").rightClick().whileSneaking().withItem("mekanism:configurator");
                scene.world.modifyBlock([3,3,5], (curState) => curState.with("active", "true"), false);
		scene.idle(60);

            }
        )
        })