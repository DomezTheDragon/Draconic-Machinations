Ponder.registry((event) => {
    event.create(
            "mekanismgenerators:fission_reactor_casing").scene(
            "fission_reactor",
            "The Fission Reactor",
            "kubejs:fission_reactor",
            (scene, util) => {
                scene.scaleSceneView(0.65);
                scene.setSceneOffsetY(-2);
            
            scene.world.showSection([0,0,0, 7,0,7], Facing.UP);
            scene.idle(25);
            scene.world.showSection([3,1,3, 7,6,7], Facing.DOWN);
            scene.idle(20);

            scene.overlay.showOutline(PonderPalette.GREEN, "fissionOutline1", util.select.fromTo(3,1,3, 7,6,7), 70);
            scene.idle(10)
            scene.text(55, "This is a Fission Reactor.", [3,4,8]).colored(PonderPalette.GREEN);
            scene.idle(65);
            scene.text(55, "It's size can range from 3x3x4 to 18x18x18", [3,4,8]).colored(PonderPalette.GREEN);
            scene.idle(65);

            scene.overlay.showOutline(PonderPalette.RED, "fissionValve1", util.select.position(6,2,3), 65);
            scene.idle(10);
            scene.text(55, "The Fission Reactor needs a fuel input...", [6.5,2.5,3]).colored(PonderPalette.RED).attachKeyFrame();
            scene.idle(65);

            scene.overlay.showOutline(PonderPalette.BLUE, "fissionValve2", util.select.position(4,2,3),65);
            scene.idle(10);
            scene.text(55, "... A coolant input, such as sodium or water...", [4.5,2.5,3]).colored(PonderPalette.BLUE);
            scene.idle(65);

            scene.overlay.showOutline(PonderPalette.RED, "fissionValve3", util.select.position(3,2,4),65);
            scene.idle(10);
            scene.text(55, "... A waste output, which is set using a Configurator...", [3,2.5,4.5]).colored(PonderPalette.RED);
            scene.idle(65);
            scene.showControls(55, [3,3,4.5], "down").rightClick().whileSneaking().withItem("mekanism:configurator");
            scene.world.modifyBlock([3,2,4], (curState) => curState.with("mode", "output_waste"), false);
            scene.idle(65);

            scene.overlay.showOutline(PonderPalette.BLUE, "fissionValve4", util.select.position(3,2,6), 65);
            scene.idle(10);
            scene.text(55, "... And a coolant output, also set with a Configurator.", [3,2.5,6.5]).colored(PonderPalette.BLUE);
            scene.idle(65);
            scene.showControls(55, [3,3,6.5], "down").rightClick().whileSneaking().withItem("mekanism:configurator");
            scene.world.modifyBlock([3,2,6], (curState) => curState.with("mode", "output_waste"), false);
            scene.idle(10);
            scene.world.modifyBlock([3,2,6], (curState) => curState.with("mode", "output_coolant"), false);
            scene.idle(65);
            
            scene.world.hideSection([6,6,3, 3,2,3], Facing.UP);
            scene.world.hideSection([3,6,6, 3,2,4], Facing.UP);
            scene.world.hideSection([4,6,4, 6,6,6], Facing.UP);

            scene.overlay.showOutline(PonderPalette.GREEN, "controlRod1", util.select.fromTo(4,2,4, 4,5,4), 65);
            scene.overlay.showOutline(PonderPalette.GREEN, "controlRod2", util.select.fromTo(6,2,4, 6,5,4), 65);
            scene.overlay.showOutline(PonderPalette.GREEN, "controlRod3", util.select.fromTo(5,2,5, 5,5,5), 65);
            scene.overlay.showOutline(PonderPalette.GREEN, "controlRod4", util.select.fromTo(4,2,6, 4,5,6), 65);
            scene.overlay.showOutline(PonderPalette.GREEN, "controlRod5", util.select.fromTo(6,2,6, 6,5,6), 65);

            scene.idle(10);
            scene.text(55, "These are the control rods. They should not touch each other horizontally, so it's best to have them in a checkerboard like this", [4.5,3.5,4.5]).colored(PonderPalette.GREEN).attachKeyFrame(); 
            scene.idle(95);

            scene.world.showSection([6,6,3, 3,2,3], Facing.DOWN);
            scene.world.showSection([3,6,6, 3,2,4], Facing.DOWN);
            scene.world.showSection([4,6,4, 6,6,6], Facing.DOWN);
            }
        )
        })