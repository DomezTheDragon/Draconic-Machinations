// priority: 0

// Visit the wiki for more info - https://kubejs.com/

console.info('Hello, World! (Loaded client scripts)')

ClientEvents.lang('en_us', event => {
    event.renameItem('create_better_motors:raw_reggarfonite_block', "Block of Raw Reggarfonite")
})