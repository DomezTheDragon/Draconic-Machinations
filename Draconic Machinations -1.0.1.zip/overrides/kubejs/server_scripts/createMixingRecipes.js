ServerEvents.recipes(event => {

  event.remove({ id: 'createutilities:mixing/void_steel_ingot' })

  event.recipes.create.mixing('mekanism:ingot_steel', ['minecraft:iron_ingot','2x #minecraft:coals']).superheated()
  event.recipes.create.mixing('createutilities:void_steel_ingot', ['mekanism:ingot_steel','2x minecraft:ender_pearl']).superheated()

  event.recipes.create.mixing('morered:red_alloy_ingot', ['#morered:red_alloyable_ingots','2x minecraft:redstone']).heated()
})