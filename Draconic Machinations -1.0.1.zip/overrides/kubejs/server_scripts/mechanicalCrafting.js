ServerEvents.recipes(event => {

event.recipes.create.mechanical_crafting('kubejs:creative_shard', [
    ' MMM ',
    'MASAM',
    'MSNSM',
    'MASAM',
    ' MMM '
  ], {
    M: 'apotheosis:mythic_material',
    A: 'mekanism:pellet_antimatter',
    S: 'mysticalagriculture:awakened_supremium_gemstone_block',
    N: 'minecraft:netherite_block'
  })

event.recipes.create.mechanical_crafting('kubejs:creative_star', [
    ' SSS ',
    'SSSSS',
    'SSNSS',
    'SSSSS',
    ' SSS '
  ], {
    S: 'kubejs:creative_shard',
    N: 'minecraft:nether_star'
  })

event.recipes.create.mechanical_crafting('create:creative_blaze_cake', [
    ' B B B ',
    'B BSB B',
    'BBBCBBB',
    'BBBBBBB'
  ], {
    B: 'minecraft:blaze_powder',
    C: 'create:blaze_cake',
    S: 'kubejs:creative_shard'
  })

event.recipes.create.mechanical_crafting('create:creative_motor', [
    'SNS',
    ' MD',
    'SNS'
  ], {
    D: 'create:shaft',
    M: 'create_better_motors:nitro_motor',
    N: 'create:sturdy_sheet',
    S: 'kubejs:creative_shard'
  })

event.recipes.create.mechanical_crafting(Item.of('botania:mana_tablet', 1, {creative:1}), [
    'LLLLL',
    'LPPPL',
    'LPSPL',
    'LPPPL',
    'LLLLL'
  ], {
    L: 'botania:livingrock',
    P: 'botania:mana_pearl',
    S: 'kubejs:creative_star'
  })

event.recipes.create.mechanical_crafting('botania:creative_pool', [
    'LLLLL',
    'LPPPL',
    'LSPSL',
    'LPPPL',
    'LLLLL'
  ], {
    L: 'botania:shimmerrock',
    P: 'botania:mana_diamond',
    S: 'kubejs:creative_star'
  })

event.recipes.create.mechanical_crafting('appbot:creative_mana_cell', [
    'GGGGG',
    'LPSPL',
    'LPPPL',
    'LSPSL',
    'LLLLL'
  ], {
    L: 'botania:manasteel_ingot',
    G: 'ae2:quartz_glass',
    P: 'botania:life_essence',
    S: 'kubejs:creative_star'
  })

event.recipes.create.mechanical_crafting(Item.of('tconstruct:creative_slot', 1, {slot:"upgrades"}), [
    'AAAAA',
    'AABAA',
    ' ASA ',
    'AAAAA'
  ], {
    A: 'minecraft:anvil',
    B: 'minecraft:writable_book',
    S: 'kubejs:creative_shard'
  })

event.recipes.create.mechanical_crafting(Item.of('tconstruct:creative_slot', 1, {slot:"abilities"}), [
    'AAAAA',
    'ASBSA',
    ' AAA ',
    'AAAAA'
  ], {
    A: 'minecraft:anvil',
    B: 'minecraft:dragon_head',
    S: 'kubejs:creative_shard'
  })

event.recipes.create.mechanical_crafting(Item.of('tconstruct:creative_slot', 1, {slot:"defense"}), [
    'AAAAA',
    'AABAA',
    ' ASA ',
    'AAAAA'
  ], {
    A: 'minecraft:anvil',
    B: 'tconstruct:earth_slime_crystal_block',
    S: 'kubejs:creative_shard'
  })

event.recipes.create.mechanical_crafting('create_sa:creative_filling_tank', [
    'CCC',
    'AWA',
    'ASA',
    'AFA',
    'CCC'
  ], {
    A: 'create:sturdy_sheet',
    S: 'kubejs:creative_shard',
    C: 'minecraft:copper_block',
    W: 'create_sa:large_filling_tank',
    F: 'create_sa:large_fueling_tank'
  })

event.recipes.create.mechanical_crafting(Item.of('mekanism:creative_energy_cube', 1, {mekData: {EnergyContainers: [{Container: 0, stored: "18446744073709551615.9999"}]} }), [
    'EEEEE',
    'ERSRE',
    'ERIRE',
    'ERRRE',
    'EEEEE'
  ], {
    I: 'mekanism_extras:infinite_energy_cube',
    S: 'kubejs:creative_star',
    R: 'minecraft:redstone_block',
    E: 'mekanism:ingot_steel' //ingot and steel!
  })

event.recipes.create.mechanical_crafting('infinitestoragecell:infinite_cell_component', [
    'AAAAA',
    'APSPA',
    'ASCSA',
    'APSPA',
    'AAAAA'
  ], {
    A: 'advanced_ae:quantum_alloy',
    C: 'megacells:cell_component_256m',
    P: `advanced_ae:quantum_processor`,
    S: 'kubejs:creative_shard'
  })

//replacing create better motors inputs

  //adding capacitors
event.replaceInput(
  { id: 'create_better_motors:blocks/starter_motor' }, 
  'createaddition:copper_spool',
  'powah:capacitor_basic'
)

event.replaceInput(
  { id: 'create_better_motors:blocks/basic_motor' }, 
  'createaddition:gold_spool',
  'powah:capacitor_basic_large'
)

event.replaceInput(
  { id: 'create_better_motors:blocks/hardened_motor' }, 
  'createaddition:gold_spool',
  'powah:capacitor_hardened'
)

event.replaceInput(
  { id: 'create_better_motors:blocks/blazing_motor' }, 
  'createaddition:gold_spool',
  'powah:capacitor_blazing'
)

event.replaceInput(
  { id: 'create_better_motors:blocks/niotic_motor' }, 
  'createaddition:electrum_spool',
  'powah:capacitor_niotic'
)

event.replaceInput(
  { id: 'create_better_motors:blocks/spirited_motor' }, 
  'createaddition:electrum_spool',
  'powah:capacitor_spirited'
)

event.replaceInput(
  { id: 'create_better_motors:blocks/nitro_motor' }, 
  'createaddition:electrum_spool',
  'powah:capacitor_nitro'
)
  //replacing top with andesite

event.replaceInput(
  { id: 'create_better_motors:blocks/basic_motor' }, 
  'minecraft:iron_block',
  'create:andesite_alloy'
)  

event.replaceInput(
  { id: 'create_better_motors:blocks/hardened_motor' }, 
  `create_better_motors:reggarfonite_block`,
  'create:andesite_alloy'
)  

event.replaceInput(
  { id: 'create_better_motors:blocks/blazing_motor' }, 
  'minecraft:gold_block',
  'create:andesite_alloy'
)  

event.replaceInput(
  { id: 'create_better_motors:blocks/niotic_motor' }, 
  'minecraft:netherite_ingot',
  'create:andesite_alloy'
)  

event.replaceInput(
  { id: 'create_better_motors:blocks/spirited_motor' }, 
  'minecraft:dragon_head',
  'create:andesite_alloy'
)  

event.replaceInput(
  { id: 'create_better_motors:blocks/nitro_motor' }, 
  'minecraft:nether_star',
  'create:andesite_alloy'
)  

//replacing create better motors upgrade inputs

  //adding capacitors
event.replaceInput(
  { id: 'create_better_motors:blocks/mechanical_crafting/upgrades/starter_tier_upgrade' }, 
  'createaddition:copper_spool',
  'powah:capacitor_basic'
)

event.replaceInput(
  { id: 'create_better_motors:blocks/mechanical_crafting/upgrades/basic_tier_upgrade' }, 
  'createaddition:gold_spool',
  'powah:capacitor_basic_large'
)

event.replaceInput(
  { id: 'create_better_motors:blocks/mechanical_crafting/upgrades/hardened_tier_upgrade' }, 
  'createaddition:gold_spool',
  'powah:capacitor_hardened'
)

event.replaceInput(
  { id: 'create_better_motors:blocks/mechanical_crafting/upgrades/blazing_tier_upgrade' }, 
  'createaddition:gold_spool',
  'powah:capacitor_blazing'
)

event.replaceInput(
  { id: 'create_better_motors:blocks/mechanical_crafting/upgrades/niotic_tier_upgrade' }, 
  'createaddition:electrum_spool',
  'powah:capacitor_niotic'
)

event.replaceInput(
  { id: 'create_better_motors:blocks/mechanical_crafting/upgrades/spirited_tier_upgrade' }, 
  'createaddition:electrum_spool',
  'powah:capacitor_spirited'
)

event.replaceInput(
  { id: 'create_better_motors:blocks/mechanical_crafting/upgrades/nitro_tier_upgrade' }, 
  'createaddition:electrum_spool',
  'powah:capacitor_nitro'
)
  //replacing top with andesite

event.replaceInput(
  { id: 'create_better_motors:blocks/mechanical_crafting/upgrades/basic_tier_upgrade' }, 
  'minecraft:iron_block',
  'create:andesite_alloy'
)  

event.replaceInput(
  { id: 'create_better_motors:blocks/mechanical_crafting/upgrades/hardened_tier_upgrade' }, 
  `create_better_motors:reggarfonite_block`,
  'create:andesite_alloy'
)  

event.replaceInput(
  { id: 'create_better_motors:blocks/mechanical_crafting/upgrades/blazing_tier_upgrade' }, 
  'minecraft:gold_block',
  'create:andesite_alloy'
)  

event.replaceInput(
  { id: 'create_better_motors:blocks/mechanical_crafting/upgrades/niotic_tier_upgrade' }, 
  'minecraft:netherite_ingot',
  'create:andesite_alloy'
)  

event.replaceInput(
  { id: 'create_better_motors:blocks/mechanical_crafting/upgrades/spirited_tier_upgrade' }, 
  'minecraft:dragon_head',
  'create:andesite_alloy'
)  

event.replaceInput(
  { id: 'create_better_motors:blocks/mechanical_crafting/upgrades/nitro_tier_upgrade' }, 
  'minecraft:nether_star',
  'create:andesite_alloy'
)  

})

