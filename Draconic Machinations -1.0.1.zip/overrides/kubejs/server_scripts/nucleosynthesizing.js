ServerEvents.recipes(event => {

function APNS(output,input,antimatter) {
event.custom({
  "type": "mekanism:nucleosynthesizing",
  "itemInput": {"ingredient": {"item": input}},
  "gasInput": {"gas": "mekanism:antimatter","amount": antimatter},
  "output": {"item": output},
  "duration": 100
})
}

APNS("apotheosis:mythic_material","kubejs:dull_pearl",50)

})