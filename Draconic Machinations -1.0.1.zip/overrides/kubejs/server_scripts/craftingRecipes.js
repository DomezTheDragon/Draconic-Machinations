ServerEvents.recipes(event => {

event.remove({output: `powah:dielectric_paste`})
event.remove({ mod: 'infinitestoragecell' })
event.remove({output:'#hexcasting:staves'})

function hexStaff(output, woodtypeInput) {
    event.shaped(output, [
      ' MA',
      ' WM',
      'S  '
    ], {
      A: 'hexcasting:charged_amethyst',
      S: 'minecraft:stick',
      M: 'botania:manaweave_cloth',
      W: woodtypeInput
    })
  }

function essenceExpensive(output, essenceInput, expense) {
    event.remove({output:output})
    event.shaped(output, [
      'MEM',
      'ECE',
      'MEM'
    ], {
      M: expense,
      E: essenceInput,
      C: '#mysticalagriculture:infusion_crystals'
    })
  }

event.remove({id: `everycomp:q/traversable_leaves/dev_hedge`})
event.remove({id: `everycomp:q/traversable_leaves/dev_leaf_carpet`})
event.remove({id: `everycomp:mcf/traversable_leaves/dev_hedge`})
event.remove({id: `everycomp:rfm/traversable_leaves/dev_hedge`})
event.remove({id: `everycomp:cfm/traversable_leaves/dev_hedge`})
event.remove({id:'mysticalagriculture:prudentium_block_combine'})
event.remove({id:'mysticalagriculture:tertium_block_combine'})
event.remove({id:'mysticalagriculture:imperium_block_combine'})
event.remove({id:'mysticalagriculture:supremium_block_combine'})
event.remove({id: `bhc:red_heart_canister`})
event.remove({id: `bhc:yellow_heart_canister`})
event.remove({id: `bhc:green_heart_canister`})
event.remove({id: `bhc:blue_heart_canister`})
event.remove({id: `bhc:smithing/soul_heart_canister`})

essenceExpensive('mysticalagriculture:prudentium_essence', 'mysticalagriculture:inferium_essence', 'botania:elementium_ingot')
essenceExpensive('mysticalagriculture:tertium_essence', 'mysticalagriculture:prudentium_essence', 'botania:mana_diamond')
essenceExpensive('mysticalagriculture:imperium_essence', 'mysticalagriculture:tertium_essence', 'botania:terrasteel_ingot')
essenceExpensive('mysticalagriculture:supremium_essence', 'mysticalagriculture:imperium_essence', 'botania:gaia_ingot')

hexStaff('hexcasting:staff/oak','minecraft:oak_planks')
hexStaff('hexcasting:staff/spruce','minecraft:spruce_planks')
hexStaff('hexcasting:staff/birch','minecraft:birch_planks')
hexStaff('hexcasting:staff/jungle','minecraft:jungle_planks')
hexStaff('hexcasting:staff/acacia','minecraft:acacia_planks')
hexStaff('hexcasting:staff/dark_oak','minecraft:dark_oak_planks')
hexStaff('hexcasting:staff/crimson','minecraft:crimson_planks')
hexStaff('hexcasting:staff/warped','minecraft:warped_planks')
hexStaff('hexcasting:staff/mangrove','minecraft:mangrove_planks')
hexStaff('hexcasting:staff/cherry','minecraft:cherry_planks')
hexStaff('hexcasting:staff/edified','hexcasting:edified_planks')
hexStaff('hexcasting:staff/bamboo','minecraft:bamboo_planks')
hexStaff('hexcasting:staff/quenched','hexcasting:quenched_allay_shard')
hexStaff('hexcasting:staff/mindsplice','#hexcasting:brainswept_circle_components')

event.remove({id:'moremekanismprocessing:processing/amethyst/gem/from_dust'})



event.shaped(
  Item.of('hexcasting:slate_amethyst_tiles', 4),
  [
    'AS',
    'SA'
  ],
  {
    S: 'hexcasting:slate_block',
    A: 'hexcasting:amethyst_tiles' 
  }
)

event.remove({id: 'mekanism:metallurgic_infuser'})
event.remove({id: 'mekanismgenerators:heat_generator'})
event.remove({id: 'mekanism:basic_universal_cable'})
event.remove({id: 'ae2:network/blocks/inscribers'})
event.remove({id: 'ae2:network/blocks/crystal_processing_charger'})

event.remove({id: `fluxnetworks:fluxcore`})

event.shaped(`mekanism:metallurgic_infuser`,
  [ `SFS`,
    `ROR`,
    `SFS`
  ], {
    S: `mekanism:ingot_steel`,
    F: 'minecraft:furnace',
    R: 'minecraft:redstone',
    O: 'mekanism:ingot_osmium'
  })

event.shaped(`mekanismgenerators:heat_generator`,
  [ `III`,
    `POP`,
    `CFC`
  ], {
    I: `minecraft:iron_ingot`,
    P: '#minecraft:planks',
    C: 'createaddition:copper_spool',
    O: 'mekanism:ingot_osmium',
    F: 'minecraft:furnace'
  })

event.shaped(`mekanism:basic_universal_cable`,
  [ `SIS`
  ], {
    S: `mekanism:ingot_steel`,
    I: `mekanism:alloy_infused`
  })

event.shaped(`ae2:inscriber`,
  [ `SPS`,
    `C S`,
    `SPS`
  ], {
    S: `mekanism:ingot_steel`,
    C: 'mekanism:ultimate_control_circuit',
    P: 'minecraft:sticky_piston'//hah SCP
  })

event.shaped('ae2:charger',
  [ `SCS`,
    `S  `,
    `SCS`
  ], {
    S: `mekanism:ingot_steel`,
    C: 'mekanism:ultimate_control_circuit'
  })

event.shaped('fluxnetworks:flux_core',
  [ `FDF`,
    `DED`,
    `FDF`
  ], {
    F: `fluxnetworks:flux_dust`,
    D: 'powah:dielectric_paste',
    E: `minecraft:ender_eye`
  })

function piping(output, additive) {
    event.remove({output:output})
    event.shaped(output, [
      'III',
      'ACA',
      'III'
    ], {
      I: 'minecraft:iron_ingot',
      A: additive,
      C: 'createaddition:copper_spool'
    })
  }
piping('pipez:item_pipe','minecraft:dropper')
piping('pipez:fluid_pipe','minecraft:bucket')
piping('pipez:energy_pipe','minecraft:redstone_block')
piping('pipez:gas_pipe','mekanism:alloy_infused')

event.remove({output:'computercraft:computer_normal'})
event.remove({id:'computercraft:computer_advanced'})
event.remove({output:'computercraft:pocket_computer_normal'})
event.remove({id:'computercraft:pocket_computer_advanced'})
event.remove({id:'buddingcrystals:crystal_catalyst'})

event.shapeless(`bhc:soul_heart_canister`,
  [
    `bhc:blue_heart_canister`,
    `3x bhc:soul_heart_crystal`
  ]
)

event.shapeless(`bhc:red_heart_canister`,
  [
    `bhc:blue_heart_canister`
  ]
)
event.shapeless(`bhc:yellow_heart_canister`,
  [
    `bhc:red_heart_canister`
  ]
)
event.shapeless(`bhc:green_heart_canister`,
  [
    `bhc:yellow_heart_canister`
  ]
)
event.shapeless(`bhc:blue_heart_canister`,
  [
    `bhc:green_heart_canister`
  ]
)

event.shapeless(`24x powah:dielectric_paste`,
  [
    `3x #minecraft:coals`,
    `2x minecraft:clay_ball`,
    `2x mekanism:sawdust`,
    `1x minecraft:lava_bucket`
  ]
)

event.shapeless(`16x powah:dielectric_paste`,
  [
    `2x #minecraft:coals`,
    `1x minecraft:clay_ball`,
    `2x mekanism:sawdust`,
    `1x minecraft:blaze_powder`
  ]
)

event.shapeless(`infinitestoragecell:infinity_item_cell`,
  [
    `1x infinitestoragecell:infinite_cell_component`,
    `1x ae2_mega_things:mega_item_disk_housing`
  ]
)

event.shapeless(`infinitestoragecell:infinity_fluid_cell`,
  [
    `1x infinitestoragecell:infinite_cell_component`,
    `1x ae2_mega_things:mega_fluid_disk_housing`
  ]
)

event.shapeless(`infinitestoragecell:infinity_chemical_cell`,
  [
    `1x infinitestoragecell:infinite_cell_component`,
    `1x ae2_mega_things:mega_chemical_disk_housing`
  ]
)  

event.shapeless('apotheosis:common_material', 
  [
    '3x botania:manasteel_nugget',
    '3x create:brass_nugget', 	
    '3x minecraft:gold_nugget'
  ]
)

event.shaped(`bhc:blue_heart_canister`,
  [
    `NBG`,
    `BCB`,
    `GBN`
  ], {
    N: `powah:crystal_nitro`,
    B: `bhc:blue_heart`,
    G: `botania:life_essence`,
    C: `bhc:canister`
  }
)

event.shaped('apotheosis:uncommon_material', 
    [
      'NMN',
      'CGC',
      'NMN'
    ], {
      C: 'apotheosis:common_material',
      G: 'minecraft:green_wool',
      N: 'mekanism:nugget_refined_glowstone',
      M: 'botania:manaweave_cloth'
    })

event.shaped('apotheosis:rare_material', 
    [
      ' M ',
      'UGU'
    ], {
      U: 'apotheosis:uncommon_material',
      M: 'ae2:charged_certus_quartz_crystal',
      G: 'botania:life_essence'
    })

event.shapeless(
  Item.of('apotheosis:epic_material'), 
  [
    '2x apotheosis:rare_material',
    '1x mekanism:pellet_plutonium', 	
    '3x mysticalagriculture:imperium_essence'
  ]
)

event.shaped('kubejs:dull_pearl', 
    [
      'SAS',
      'EGE',
      'SAS'
    ], {
      S: 'mysticalagriculture:awakened_supremium_essence',
      E: 'apotheosis:epic_material',
      A: 'mythicbotany:alfsteel_ingot',
      G: 'mysticalagriculture:awakened_supremium_gemstone'
    })


event.shaped('buddingcrystals:crystal_catalyst', 
    [
      'CGC',
      'GAG',
      'CGC'
    ], {
      C: 'apotheosis:rare_material',
      G: 'botania:life_essence',
      A: 'ae2:growth_accelerator'
    })

event.shaped('computercraft:computer_normal', 
    [
      'SSS',
      'SCS',
      'SGS'
    ], {
      S: 'minecraft:stone',
      G: 'minecraft:glass_pane',
      C: 'mekanism:basic_control_circuit'
    })

event.shaped('computercraft:computer_advanced', 
    [
      'GGG',
      'GCG',
      'GSG'
    ], {
      G: 'minecraft:gold_ingot',
      S: 'minecraft:glass_pane',
      C: 'mekanism:advanced_control_circuit'
    })


event.shaped('computercraft:pocket_computer_normal', [
      'SAS',
      'SCS',
      'SGS'
    ], {
      S: 'minecraft:stone',
      G: 'minecraft:glass_pane',
      C: 'mekanism:basic_control_circuit',
      A: 'minecraft:golden_apple'
    })

event.shaped('computercraft:pocket_computer_advanced', [
      'GAG',
      'GCG',
      'GSG'
    ], {
      G: 'minecraft:gold_ingot',
      S: 'minecraft:glass_pane',
      C: 'mekanism:advanced_control_circuit',
      A: 'minecraft:golden_apple'
    })
})