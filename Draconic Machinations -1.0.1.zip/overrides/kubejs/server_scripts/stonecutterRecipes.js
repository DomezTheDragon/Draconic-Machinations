ServerEvents.recipes(event => {

  event.stonecutting('hexcasting:amethyst_bricks', 'minecraft:amethyst_block')
  event.stonecutting('hexcasting:amethyst_bricks_small', 'minecraft:amethyst_block')
  event.stonecutting('hexcasting:amethyst_pillar', 'minecraft:amethyst_block')

  event.stonecutting('hexcasting:slate_tiles', 'hexcasting:slate_block')
  event.stonecutting('hexcasting:slate_bricks', 'hexcasting:slate_block')
  event.stonecutting('hexcasting:slate_bricks_small', 'hexcasting:slate_block')
  event.stonecutting('hexcasting:slate_pillar', 'hexcasting:slate_block')

  event.stonecutting('hexcasting:slate_amethyst_bricks', 'hexcasting:slate_amethyst_tiles')
  event.stonecutting('hexcasting:slate_amethyst_bricks_small', 'hexcasting:slate_amethyst_tiles')
  event.stonecutting('hexcasting:slate_amethyst_pillar', 'hexcasting:slate_amethyst_tiles')

  event.stonecutting('hexcasting:quenched_allay_tiles', 'hexcasting:quenched_allay')
  event.stonecutting('hexcasting:quenched_allay_bricks', 'hexcasting:quenched_allay')
  event.stonecutting('hexcasting:quenched_allay_bricks_small', 'hexcasting:quenched_allay')
})